package main

import (
	"bufio"
	"context"
	"crypto/rand"
	"encoding/hex"
	"errors"
	"flag"
	"fmt"
	"log"
	"net"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"
)

const (
	defaultTCPAddr = ":9000"
	defaultUDPAddr = ":9001"
	maxLineBytes   = 2048
	sessionIDLen   = 7
)

type client struct {
	id       string
	username string
	conn     net.Conn
	writeMu  sync.Mutex
	queued   bool
	matchID  string
	player   int
}

func (c *client) send(line string) error {
	c.writeMu.Lock()
	defer c.writeMu.Unlock()
	if !strings.HasSuffix(line, "\n") {
		line += "\n"
	}
	_ = c.conn.SetWriteDeadline(time.Now().Add(5 * time.Second))
	_, err := c.conn.Write([]byte(line))
	return err
}

type match struct {
	id        string
	p1        *client
	p2        *client
	endpoint1 *net.UDPAddr
	endpoint2 *net.UDPAddr
	started   bool
	created   time.Time
}

type server struct {
	mu       sync.Mutex
	clients  map[string]*client
	queue    []*client
	matches  map[string]*match
	tcpLn    net.Listener
	udpConn  *net.UDPConn
	tcpAddr  string
	udpAddr  string
	guestSeq uint64
	ready    chan struct{}
}

func newServer(tcpAddr, udpAddr string) *server {
	return &server{
		clients: make(map[string]*client),
		matches: make(map[string]*match),
		tcpAddr: tcpAddr,
		udpAddr: udpAddr,
		ready:   make(chan struct{}),
	}
}

func randomBytes(n int) ([]byte, error) {
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		return nil, err
	}
	return b, nil
}

func randomSessionID() (string, error) {
	const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
	b, err := randomBytes(sessionIDLen)
	if err != nil {
		return "", err
	}
	out := make([]byte, sessionIDLen)
	for i := range out {
		out[i] = alphabet[int(b[i])%len(alphabet)]
	}
	return string(out), nil
}

func randomToken() (string, error) {
	b, err := randomBytes(24)
	if err != nil {
		return "", err
	}
	return hex.EncodeToString(b), nil
}

func randomUUID() (string, error) {
	b, err := randomBytes(16)
	if err != nil {
		return "", err
	}
	b[6] = (b[6] & 0x0f) | 0x40
	b[8] = (b[8] & 0x3f) | 0x80
	return fmt.Sprintf("%08x-%04x-%04x-%04x-%012x",
		b[0:4], b[4:6], b[6:8], b[8:10], b[10:16]), nil
}

func (s *server) nextGuestName() string {
	s.guestSeq++
	// PROFILE is parsed by 3SX with %7s, so keep this <=7 chars.
	return fmt.Sprintf("g%06d", s.guestSeq%1000000)
}

func (s *server) run(ctx context.Context) error {
	ln, err := net.Listen("tcp4", s.tcpAddr)
	if err != nil {
		return fmt.Errorf("listen tcp %s: %w", s.tcpAddr, err)
	}
	udpAddr, err := net.ResolveUDPAddr("udp4", s.udpAddr)
	if err != nil {
		_ = ln.Close()
		return fmt.Errorf("resolve udp %s: %w", s.udpAddr, err)
	}
	udpConn, err := net.ListenUDP("udp4", udpAddr)
	if err != nil {
		_ = ln.Close()
		return fmt.Errorf("listen udp %s: %w", s.udpAddr, err)
	}
	s.tcpLn = ln
	s.udpConn = udpConn
	close(s.ready)

	log.Printf("3SX Fistbump coordinator listening TCP %s / UDP %s", ln.Addr(), udpConn.LocalAddr())

	var wg sync.WaitGroup
	wg.Add(2)
	go func() {
		defer wg.Done()
		s.acceptLoop(ctx)
	}()
	go func() {
		defer wg.Done()
		s.udpLoop(ctx)
	}()

	<-ctx.Done()
	_ = ln.Close()
	_ = udpConn.Close()
	wg.Wait()
	return nil
}

func (s *server) acceptLoop(ctx context.Context) {
	for {
		conn, err := s.tcpLn.Accept()
		if err != nil {
			if ctx.Err() != nil || errors.Is(err, net.ErrClosed) {
				return
			}
			log.Printf("tcp accept: %v", err)
			continue
		}
		go s.handleClient(ctx, conn)
	}
}

func (s *server) allocateClient(conn net.Conn) (*client, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	var id string
	for i := 0; i < 20; i++ {
		candidate, err := randomSessionID()
		if err != nil {
			return nil, err
		}
		if _, exists := s.clients[candidate]; !exists {
			id = candidate
			break
		}
	}
	if id == "" {
		return nil, errors.New("could not allocate unique session id")
	}

	c := &client{id: id, username: s.nextGuestName(), conn: conn}
	s.clients[id] = c
	return c, nil
}

func (s *server) handleClient(ctx context.Context, conn net.Conn) {
	c, err := s.allocateClient(conn)
	if err != nil {
		log.Printf("allocate client: %v", err)
		_ = conn.Close()
		return
	}
	defer func() {
		s.removeClient(c)
		_ = conn.Close()
	}()

	log.Printf("tcp connect session=%s remote=%s profile=%s", c.id, conn.RemoteAddr(), c.username)
	if err := c.send("SESSION " + c.id); err != nil {
		return
	}

	scanner := bufio.NewScanner(conn)
	scanner.Buffer(make([]byte, 1024), maxLineBytes)
	for scanner.Scan() {
		select {
		case <-ctx.Done():
			return
		default:
		}
		line := strings.TrimSpace(scanner.Text())
		if line == "" {
			continue
		}
		if err := s.handleCommand(c, line); err != nil {
			log.Printf("session=%s command=%q error=%v", c.id, line, err)
		}
	}
	if err := scanner.Err(); err != nil && !errors.Is(err, net.ErrClosed) {
		log.Printf("session=%s tcp read: %v", c.id, err)
	}
}

func (s *server) handleCommand(c *client, line string) error {
	fields := strings.Fields(line)
	if len(fields) == 0 {
		return nil
	}

	switch fields[0] {
	case "HELLO":
		return s.login(c)
	case "REFRESH":
		// This development coordinator intentionally uses guest identities.
		// Accept any previously cached token and issue a fresh short-lived one.
		return s.login(c)
	case "QUEUE":
		if len(fields) != 2 {
			return c.send("ERROR bad_queue")
		}
		switch fields[1] {
		case "add":
			return s.queueAdd(c)
		case "remove":
			s.queueRemove(c, true)
			return nil
		default:
			return c.send("ERROR bad_queue")
		}
	case "DECLINE":
		if len(fields) != 2 {
			return c.send("ERROR bad_decline")
		}
		s.decline(c, fields[1])
		return nil
	default:
		// Current 3SX silently ignores unknown server commands, so reciprocate.
		log.Printf("session=%s ignoring unknown command %q", c.id, line)
		return nil
	}
}

func (s *server) login(c *client) error {
	token, err := randomToken()
	if err != nil {
		return err
	}
	expiry := time.Now().Add(24 * time.Hour).Unix()
	// 3SX parses expiry with %d, so keep it within signed 32-bit epoch range.
	if expiry > 2147483647 {
		expiry = 2147483647
	}
	if err := c.send(fmt.Sprintf("TOKEN refresh %s %d", token, expiry)); err != nil {
		return err
	}
	return c.send("PROFILE " + c.username)
}

func (s *server) queueAdd(c *client) error {
	s.mu.Lock()
	if c.matchID != "" || c.queued {
		s.mu.Unlock()
		return nil
	}

	// Drop stale queue entries while looking for an opponent.
	var opponent *client
	for len(s.queue) > 0 {
		q := s.queue[0]
		s.queue = s.queue[1:]
		if q != nil && q != c && q.queued && q.matchID == "" {
			opponent = q
			break
		}
	}

	if opponent == nil {
		c.queued = true
		s.queue = append(s.queue, c)
		s.mu.Unlock()
		log.Printf("queue add session=%s profile=%s", c.id, c.username)
		return nil
	}

	id, err := randomUUID()
	if err != nil {
		// Put the opponent back if ID allocation fails.
		s.queue = append([]*client{opponent}, s.queue...)
		s.mu.Unlock()
		return err
	}

	c.queued = false
	opponent.queued = false
	opponent.matchID = id
	opponent.player = 1
	c.matchID = id
	c.player = 2
	m := &match{id: id, p1: opponent, p2: c, created: time.Now()}
	s.matches[id] = m
	s.mu.Unlock()

	log.Printf("match id=%s p1=%s(%s) p2=%s(%s)", id, opponent.id, opponent.username, c.id, c.username)
	if err := opponent.send(fmt.Sprintf("MATCH %s %s", id, c.username)); err != nil {
		return err
	}
	return c.send(fmt.Sprintf("MATCH %s %s", id, opponent.username))
}

func (s *server) queueRemove(c *client, cancelMatch bool) {
	var notify *client
	var matchID string

	s.mu.Lock()
	c.queued = false
	if cancelMatch && c.matchID != "" {
		matchID = c.matchID
		if m := s.matches[matchID]; m != nil && !m.started {
			if m.p1 == c {
				notify = m.p2
			} else {
				notify = m.p1
			}
			s.clearMatchLocked(m)
		}
	}
	s.mu.Unlock()

	if notify != nil {
		_ = notify.send("CANCEL " + matchID)
	}
}

func (s *server) decline(c *client, requestedMatchID string) {
	var notify *client
	var matchID string

	s.mu.Lock()
	if c.matchID != "" && c.matchID == requestedMatchID {
		matchID = c.matchID
		if m := s.matches[matchID]; m != nil && !m.started {
			if m.p1 == c {
				notify = m.p2
			} else {
				notify = m.p1
			}
			s.clearMatchLocked(m)
		}
	}
	s.mu.Unlock()

	if notify != nil {
		_ = notify.send("CANCEL " + matchID)
	}
}

func (s *server) clearMatchLocked(m *match) {
	if m == nil {
		return
	}
	delete(s.matches, m.id)
	for _, c := range []*client{m.p1, m.p2} {
		if c != nil && c.matchID == m.id {
			c.matchID = ""
			c.player = 0
		}
	}
}

func (s *server) removeClient(c *client) {
	var notify *client
	var matchID string

	s.mu.Lock()
	delete(s.clients, c.id)
	c.queued = false
	if c.matchID != "" {
		matchID = c.matchID
		if m := s.matches[matchID]; m != nil && !m.started {
			if m.p1 == c {
				notify = m.p2
			} else {
				notify = m.p1
			}
			s.clearMatchLocked(m)
		}
	}
	s.mu.Unlock()

	if notify != nil {
		_ = notify.send("CANCEL " + matchID)
	}
	log.Printf("tcp disconnect session=%s", c.id)
}

func (s *server) udpLoop(ctx context.Context) {
	buf := make([]byte, 512)
	for {
		_ = s.udpConn.SetReadDeadline(time.Now().Add(time.Second))
		n, addr, err := s.udpConn.ReadFromUDP(buf)
		if err != nil {
			if ctx.Err() != nil || errors.Is(err, net.ErrClosed) {
				return
			}
			if ne, ok := err.(net.Error); ok && ne.Timeout() {
				continue
			}
			log.Printf("udp read: %v", err)
			continue
		}
		payload := strings.TrimSpace(string(buf[:n]))
		s.handleUDP(addr, payload)
	}
}

func (s *server) handleUDP(addr *net.UDPAddr, payload string) {
	fields := strings.Fields(payload)
	if len(fields) != 2 {
		return
	}
	sessionID, matchID := fields[0], fields[1]
	if len(sessionID) > sessionIDLen || len(matchID) > 36 {
		return
	}

	var ack *client
	var p1, p2 *client
	var ep1, ep2 *net.UDPAddr
	shouldStart := false

	s.mu.Lock()
	c := s.clients[sessionID]
	m := s.matches[matchID]
	if c != nil && m != nil && c.matchID == matchID && !m.started {
		if m.p1 == c {
			m.endpoint1 = cloneUDPAddr(addr)
		} else if m.p2 == c {
			m.endpoint2 = cloneUDPAddr(addr)
		} else {
			s.mu.Unlock()
			return
		}
		ack = c
		if m.endpoint1 != nil && m.endpoint2 != nil {
			m.started = true
			p1, p2 = m.p1, m.p2
			ep1, ep2 = cloneUDPAddr(m.endpoint1), cloneUDPAddr(m.endpoint2)
			shouldStart = true
			// Once START is sent, the coordinator is no longer in the game path.
			delete(s.matches, m.id)
			p1.matchID, p2.matchID = "", ""
		}
	}
	s.mu.Unlock()

	if ack != nil {
		_ = ack.send("UDP ok")
	}
	if shouldStart {
		log.Printf("start match=%s p1=%s peer=%s p2=%s peer=%s", matchID, p1.id, ep2, p2.id, ep1)
		_ = p1.send(fmt.Sprintf("START 1 %s:%d", ep2.IP.String(), ep2.Port))
		_ = p2.send(fmt.Sprintf("START 2 %s:%d", ep1.IP.String(), ep1.Port))
	}
}

func cloneUDPAddr(a *net.UDPAddr) *net.UDPAddr {
	if a == nil {
		return nil
	}
	ip := append(net.IP(nil), a.IP...)
	return &net.UDPAddr{IP: ip, Port: a.Port, Zone: a.Zone}
}

func envOr(name, fallback string) string {
	if v := strings.TrimSpace(os.Getenv(name)); v != "" {
		return v
	}
	return fallback
}

func main() {
	log.SetFlags(log.LstdFlags | log.Lmicroseconds)

	tcpDefault := envOr("FISTBUMP_TCP_ADDR", defaultTCPAddr)
	udpDefault := envOr("FISTBUMP_UDP_ADDR", defaultUDPAddr)
	tcpAddr := flag.String("tcp", tcpDefault, "TCP matchmaking listen address")
	udpAddr := flag.String("udp", udpDefault, "UDP NAT-discovery listen address")
	flag.Parse()

	if p := os.Getenv("FISTBUMP_TCP_PORT"); p != "" && *tcpAddr == defaultTCPAddr {
		if _, err := strconv.Atoi(p); err == nil {
			*tcpAddr = ":" + p
		}
	}
	if p := os.Getenv("FISTBUMP_UDP_PORT"); p != "" && *udpAddr == defaultUDPAddr {
		if _, err := strconv.Atoi(p); err == nil {
			*udpAddr = ":" + p
		}
	}

	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer cancel()

	s := newServer(*tcpAddr, *udpAddr)
	if err := s.run(ctx); err != nil {
		log.Fatal(err)
	}
}
