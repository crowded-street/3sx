package main

import (
	"bufio"
	"context"
	"fmt"
	"net"
	"strings"
	"testing"
	"time"
)

type testClient struct {
	conn    net.Conn
	scanner *bufio.Scanner
	session string
	profile string
}

func readLine(t *testing.T, c *testClient) string {
	t.Helper()
	_ = c.conn.SetReadDeadline(time.Now().Add(2 * time.Second))
	if !c.scanner.Scan() {
		t.Fatalf("read line failed: %v", c.scanner.Err())
	}
	return c.scanner.Text()
}

func writeLine(t *testing.T, c *testClient, line string) {
	t.Helper()
	if !strings.HasSuffix(line, "\n") {
		line += "\n"
	}
	if _, err := c.conn.Write([]byte(line)); err != nil {
		t.Fatalf("write: %v", err)
	}
}

func connectTestClient(t *testing.T, addr string) *testClient {
	t.Helper()
	conn, err := net.Dial("tcp4", addr)
	if err != nil {
		t.Fatalf("dial: %v", err)
	}
	c := &testClient{conn: conn, scanner: bufio.NewScanner(conn)}
	line := readLine(t, c)
	if _, err := fmt.Sscanf(line, "SESSION %s", &c.session); err != nil {
		t.Fatalf("bad SESSION %q: %v", line, err)
	}
	writeLine(t, c, "HELLO")
	if line = readLine(t, c); !strings.HasPrefix(line, "TOKEN refresh ") {
		t.Fatalf("expected TOKEN, got %q", line)
	}
	line = readLine(t, c)
	if _, err := fmt.Sscanf(line, "PROFILE %s", &c.profile); err != nil {
		t.Fatalf("bad PROFILE %q: %v", line, err)
	}
	return c
}

func TestEndToEndMatchmaking(t *testing.T) {
	s := newServer("127.0.0.1:0", "127.0.0.1:0")
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan error, 1)
	go func() { done <- s.run(ctx) }()

	select {
	case <-s.ready:
	case <-time.After(2 * time.Second):
		cancel()
		t.Fatal("server did not start")
	}
	defer func() {
		cancel()
		select {
		case err := <-done:
			if err != nil {
				t.Fatalf("server exit: %v", err)
			}
		case <-time.After(2 * time.Second):
			t.Fatal("server did not stop")
		}
	}()

	c1 := connectTestClient(t, s.tcpLn.Addr().String())
	defer c1.conn.Close()
	c2 := connectTestClient(t, s.tcpLn.Addr().String())
	defer c2.conn.Close()

	writeLine(t, c1, "QUEUE add")
	time.Sleep(25 * time.Millisecond)
	writeLine(t, c2, "QUEUE add")

	m1 := readLine(t, c1)
	m2 := readLine(t, c2)
	var id1, opp1, id2, opp2 string
	if _, err := fmt.Sscanf(m1, "MATCH %s %s", &id1, &opp1); err != nil {
		t.Fatalf("bad match1 %q: %v", m1, err)
	}
	if _, err := fmt.Sscanf(m2, "MATCH %s %s", &id2, &opp2); err != nil {
		t.Fatalf("bad match2 %q: %v", m2, err)
	}
	if id1 != id2 {
		t.Fatalf("match IDs differ: %s != %s", id1, id2)
	}
	if opp1 != c2.profile || opp2 != c1.profile {
		t.Fatalf("opponents wrong: %s %s", opp1, opp2)
	}

	udpServer := s.udpConn.LocalAddr().(*net.UDPAddr)
	u1, err := net.ListenUDP("udp4", &net.UDPAddr{IP: net.ParseIP("127.0.0.1"), Port: 0})
	if err != nil {
		t.Fatal(err)
	}
	defer u1.Close()
	u2, err := net.ListenUDP("udp4", &net.UDPAddr{IP: net.ParseIP("127.0.0.1"), Port: 0})
	if err != nil {
		t.Fatal(err)
	}
	defer u2.Close()

	if _, err := u1.WriteToUDP([]byte(c1.session+" "+id1), udpServer); err != nil {
		t.Fatal(err)
	}
	if _, err := u2.WriteToUDP([]byte(c2.session+" "+id1), udpServer); err != nil {
		t.Fatal(err)
	}

	lines1 := []string{readLine(t, c1), readLine(t, c1)}
	lines2 := []string{readLine(t, c2), readLine(t, c2)}
	joined1 := strings.Join(lines1, "\n")
	joined2 := strings.Join(lines2, "\n")
	if !strings.Contains(joined1, "UDP ok") || !strings.Contains(joined1, "START 1 ") {
		t.Fatalf("client1 unexpected: %q", joined1)
	}
	if !strings.Contains(joined2, "UDP ok") || !strings.Contains(joined2, "START 2 ") {
		t.Fatalf("client2 unexpected: %q", joined2)
	}

	p1 := u1.LocalAddr().(*net.UDPAddr).Port
	p2 := u2.LocalAddr().(*net.UDPAddr).Port
	if !strings.Contains(joined1, fmt.Sprintf(":%d", p2)) {
		t.Fatalf("client1 START missing peer port %d: %q", p2, joined1)
	}
	if !strings.Contains(joined2, fmt.Sprintf(":%d", p1)) {
		t.Fatalf("client2 START missing peer port %d: %q", p1, joined2)
	}
}

func TestDeclineCancelsOpponent(t *testing.T) {
	s := newServer("127.0.0.1:0", "127.0.0.1:0")
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan error, 1)
	go func() { done <- s.run(ctx) }()
	select {
	case <-s.ready:
	case <-time.After(2 * time.Second):
		cancel()
		t.Fatal("server did not start")
	}
	defer func() { cancel(); <-done }()

	c1 := connectTestClient(t, s.tcpLn.Addr().String())
	defer c1.conn.Close()
	c2 := connectTestClient(t, s.tcpLn.Addr().String())
	defer c2.conn.Close()
	writeLine(t, c1, "QUEUE add")
	writeLine(t, c2, "QUEUE add")
	m1 := readLine(t, c1)
	_ = readLine(t, c2)
	var id, opponent string
	if _, err := fmt.Sscanf(m1, "MATCH %s %s", &id, &opponent); err != nil {
		t.Fatal(err)
	}
	writeLine(t, c1, "DECLINE "+id)
	got := readLine(t, c2)
	if got != "CANCEL "+id {
		t.Fatalf("expected cancel, got %q", got)
	}
}
