module 3sx-fistbump-server

go 1.23
