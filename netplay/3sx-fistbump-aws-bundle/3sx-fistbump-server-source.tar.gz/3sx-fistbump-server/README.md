# 3SX Fistbump coordination server (development implementation)

This is a small independent server implementation targeting the current public 3SX Fistbump client protocol.
It is intended for self-hosted testing of 3SX matchmaking and NAT endpoint exchange.

## Protocol implemented

TCP control port (default `9000`):

- server -> `SESSION <7-char-id>`
- client -> `HELLO` or `REFRESH <token>`
- server -> `TOKEN refresh <token> <expiry>`
- server -> `PROFILE <7-char-name>`
- client -> `QUEUE add` / `QUEUE remove`
- server -> `MATCH <uuid> <opponent-name>`
- client -> `DECLINE <uuid>`
- server -> `CANCEL <uuid>`
- server -> `UDP ok`
- server -> `START <1|2> <peer-ip>:<peer-port>`

UDP discovery port (default `9001`):

- client -> `<session-id> <match-uuid>`

When both matched clients register their UDP source endpoints, the server sends each client a `START` line containing the other client's observed IPv4 address and UDP source port. 3SX then reuses that UDP socket for GekkoNet peer-to-peer gameplay; gameplay traffic does not transit this server.

## Authentication note

This build intentionally uses ephemeral guest profiles (`g000001`, etc.) and accepts `REFRESH` as a development login shim. It does **not** reproduce any production account/authentication backend and should not be treated as an identity service.

## Build

```bash
CGO_ENABLED=0 GOOS=linux GOARCH=amd64 \
  go build -trimpath -ldflags='-s -w' -o 3sx-fistbump-server-linux-amd64 ./cmd/fistbump
```

## Run locally

```bash
./3sx-fistbump-server -tcp :9000 -udp :9001
```

Then point a Debug 3SX build at it:

```bash
./3sx --matchmaking-ip SERVER_IP --matchmaking-port 9000
```

3SX currently uses UDP port 9001 for its Fistbump registration path.
